#ifndef GUARD_median_h
#define GUARD_median_h

#include "Vec.h"
double median(Vec<double>);

#endif